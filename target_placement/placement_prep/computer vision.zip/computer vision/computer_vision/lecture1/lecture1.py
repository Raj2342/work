#Opencv function from images – read , write , show
import cv2 # opencv use as cv2 in python 
#  load image
img = cv2.imread('photo/raj.png',1)
img = cv2.resize(img , (500 , 500)) # width , height
 # display image
# image as array it is collection of pixel value
print("colourful image",img) # print matrix of img
cv2.imshow("colourful img",img)

# for black and white
img2 = cv2.imread('photo/raj.png',0)
img2 = cv2.resize(img2,(500,500))
print("grey image",img2) # print matrix of imag2
cv2.imshow("grey image",img2)

# unchanged - color ki saturation ko incerese kar deta hai 
img3 = cv2.imread('photo/raj.png',-1)
img3 = cv2.resize(img,(500,500))
print("unchanges",img3)
cv2.imshow("unchanegd",img3)
# Wait for a key press and close the window
cv2.waitKey(0)
cv2.destroyAllWindows()