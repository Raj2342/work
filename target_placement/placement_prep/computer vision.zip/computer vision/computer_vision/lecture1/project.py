# take imge from user  colored into grey imge'
import cv2
#take input from user 
path = input("Enter the path and name of image==")
print("you enter this==",path)

#Now read image
img = cv2.imread(path,0)# load image and convert in grey 
img = cv2.resize(img,(500,700))
cv2.imshow("converted imge",img)

# target to save new image in computer 
store = cv2.waitKey(0)
if store == ord("s"):
            cv2.imwrite("C:\\Users\\techn\\Music\\placement_prep\\computer vision\\computer_vision\\photo",img)
else :
        cv2.destroyAllWindows()  
