import java.util.Scanner;

public class hexdecimal_to_decimal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the hexadecimal number:");
        String str = sc.nextLine();
        int placevalue = 1;
        int result = 0;

        for (int i = str.length() - 1; i >= 0; i--) {
            char c = str.charAt(i);
            int digit = 0;

            if (c >= '0' && c <= '9') {
                digit = c - '0';
            } else if (c >= 'A' && c <= 'F') {  
                digit = c - 'A' + 10;
            } else if (c >= 'a' && c <= 'f') { 
                digit = c - 'a' + 10;
            } else {
                System.out.println("Invalid hexadecimal character: " + c);
                sc.close();
                return;
            }

            result = result + digit * placevalue;
            placevalue = placevalue * 16;
        }

        System.out.println("Decimal equivalent: " + result);
        sc.close();
    }
}
