import java.math.*;
public class broRough {
         public static void main(String[] args) {
                
         }
}
