public class count_vowels {
            public static void main(String[] args) {
                        String str = "Hello World";
                         str = str.toLowerCase();

                         int vowles=0;
                         int consonent =0;
                         int spaces=0;
                         for(int i=0;i<str.length();i++){
                                    char c = str.charAt(i);

                                    if(c==' '){
                                      spaces++;
                                    }
                                    else if(c>='a' && c<='z'){
                                                if(c=='a' || c=='e'|| c=='i' || c=='o' || c=='u'){
                                                            vowles++;
                                                }
                                                else{
                                                            consonent++;
                                                }

                                    }
                         }
                         System.out.println(spaces+" " +vowles+" "+consonent);
            }
}
