public  class intro {
            public static void main(String[] args) {
                        String str = "HELLO";
                        for(int i=0;i<str.length();i++){
                                    System.out.println(str.charAt(i));
                        }
            }
}