public class ascii_value {
            public static void main(String[] args) {
                        String str = "Hello World";
                         str = str.toLowerCase();
                        for(int i=0;i<str.length();i++){
                            char c = str.charAt(i);
                            int ascii = (int)c;
                            System.out.println(c+ " "+ascii);

                        }
            }
}
