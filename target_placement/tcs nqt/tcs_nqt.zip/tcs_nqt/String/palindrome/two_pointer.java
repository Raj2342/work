package palindrome;
public class two_pointer {
            public static void main(String[] args) {
                        String str = "madam";
                        int first= 0;
                        int last =str.length()-1;
                        Boolean b = true;
                        while(last>first){
                                    if(str.charAt(first) != str.charAt(last)){
                                          b=false;
                                    }
                                    first++;
                                    last--;
                                    
                        }
                        if(b){
                                    System.out.println("palindrome");
                        }
                        else{
                                    System.out.println("not plaindrome");
                        }
                        
                        
            }
}
