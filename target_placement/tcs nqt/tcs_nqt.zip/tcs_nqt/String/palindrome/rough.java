package palindrome;
public class rough {
            public static void main(String[] args) {
                        String str = "madam";
                        String newstr="";
                        
                        for(int j=str.length()-1;j>=0;j--){
                                    char c = str.charAt(j);
                                    newstr= newstr+c;

                        }
                        if (str.equals(newstr)) {
                                   System.out.println("palindrome "); 
                        }
                        else{
                                    System.out.println("not plaindrome");
                        }
            }
}
