public class Remove_chacter_except_alphabet {
            public static void main(String[] args) {
                        String str = "Hello123 @MOMO#2024!";
                        String result ="";
                        str=str.toLowerCase();
                        for(int i=0;i<str.length();i++){
                                    char c= str.charAt(i);
                                    if(c>='a' && c<='z' || c>='A' && c<='Z'  ){
                                          result = result+ str.charAt(i);
                                    }
                        }
                        System.out.println(result);
            }
}
