import java.util.Arrays;
import java.util.HashMap;

public class check_anagram {

            public static Boolean anagram(String str1 , String str2) {           
                     HashMap<Character , Integer> hp = new HashMap<>();
                     if(str1.length() != str2.length()){
                         return false;
                     }
                     int n= str1.length();
                     for(int i=0;i<n;i++){
                        char c = str1.charAt(i);
                        hp.put(c,hp.getOrDefault(c,0 )+1);
                     }

                     for(int i=0;i<n;i++){
                        char c = str2.charAt(i);
                        if(hp.containsKey(c)){
                            hp.put(c, hp.get(c)-1);
                        }
                        else{
                                  return false;   
                        }
                        if(hp.get(c)<0){
                                     return false;
                        }
                     }
                     
                   
                        
            
              return true;
}

public static void main(String[] args) {
                        String str1 = "eat";
                     String str2 = "ete";
                 Boolean val=  anagram(str1 , str2);
                     if(val){
                        System.out.println("anagram");
                     }
                     else{
                        System.out.println("not anagram");
                     }
 }

}
               