public class Remove_spaces {
            public static void main(String[] args) {
                        String str = "Hello Wolrd";
                        String result ="";
                        str=str.toLowerCase();
                        for(int i=0;i<str.length();i++){
                                    char c= str.charAt(i);
                                    if(c != ' '){
                                          result = result+ str.charAt(i);
                                    }
                        }
                        System.out.println(result);
            }
}
