import java.util.*;
public class revison{
            public static void main(String[] args) {
             String s = "rat";
             String s2 = "art";
             HashMap<Character , Integer > hp = new HashMap<>();
             int n= s.length();
             if(s.length() != s2.length()){
               System.out.println("not anagram");
             }
             for(int i=0;i<n;i++){
               char c = s.charAt(i);
              
               hp.put(c,hp.getOrDefault(c, 0)+1);
             }

             for(int i=0;i<n;i++){
                 char c = s2.charAt(i);
                 if(!hp.containsKey(c)){
                    System.out.println("not annagram");
                 }
                 else{
                      hp.put(c,hp.get(c)-1);
                 }
             }
               
             System.out.println("annagram");

                        

                    

            }
            
}