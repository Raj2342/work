// binary - decimal - hexadeximal 
public class practice {
            public static void main(String[] args) {
                  int n=10;
                  int ans =0;
                for(int i=0;i<=n;i++){
                     ans = ans +i;
                }
                System.out.println(ans);
            }
}