 public class  rough{
  public static void main(String[] args) {
             
  }
 }