import java.util.HashMap;

public class ranssomNote{
 
            public static void main(String[] args) {
                        String ransomNote = "aa";
                        String magazine = "aab";
                        HashMap<Character, Integer> hp = new HashMap<>();
                        HashMap<Character, Integer> hp1 = new HashMap<>();
                        
                        for(int i=0; i<ransomNote.length(); i++){
                                    char c = ransomNote.charAt(i);
                                    hp.put(c, hp.getOrDefault(c, 0) + 1);
                                  
                                    
                        }

                        for(int i=0; i<magazine.length(); i++){
                                    char c = magazine.charAt(i);
                                    hp1.put(c, hp1.getOrDefault(c, 0) + 1);
                                    
                        }

                        for(char key : hp.keySet()){
                                    for(char key1 : hp1.keySet()){
                                                if(key == key1){
                                                            System.out.println("true");
                                                }
                                                else{
                                                            System.out.println("false");
                                                }
                                    }
                        }
            }
                        
}