'''
P(Disease) = 0.01
P(Positive | Disease) = 0.99
P(Positive | No Disease) = 0.05
P(No Disease) = 1 - 0.01 = 0.99
Goal:
Find: P(Disease | Positive) using Bayes’ Theorem
'''
p_D = 0.01
p_positive_D = 0.99
p_positive_ND=0.05
P_ND= 1-p_D
# total probability formula
p_positive = p_positive_ND*P_ND + p_positive_D*p_D
# beyes theorem
p_D_positive = (p_positive_D*p_D)/p_positive

print(p_D_positive)