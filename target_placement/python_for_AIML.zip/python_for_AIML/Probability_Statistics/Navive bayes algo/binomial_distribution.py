from math import comb
import numpy as np

# Inputs
n = 10         # total trials
p = 0.5        # probability of success
k = 5          # desired number of successes

# Binomial Probability Formula: P(X = k)
prob = comb(n, k) * (p**k) * ((1 - p)**(n - k))

# Mean and Variance
mean = n * p
variance = n * p * (1 - p)

# Print the results
print(f"P(X = {k}) = {prob:.4f}")
print(f"Mean (μ) = {mean}")
print(f"Variance (σ²) = {variance}")

#  using library 
'''
from scipy.stats import binom

n = 10
p = 0.5
k = 5

prob = binom.pmf(k, n, p)
mean, var = binom.stats(n, p)

print(f"P(X = {k}) = {prob:.4f}")
print(f"Mean = {mean}, Variance = {var}")


'''