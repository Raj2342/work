'''
a=3
y="string"
y=2
print(a)
print(y)

'''
# casting 
'''

x=int(4)
y=str("bro")
print(x)
print(y)
'''

# Get the Type
'''
x =4
y="stri8ng"
print(type(x))
print(type(y))

'''

  #print
'''

x=3
y="child"
print(f"I am {x} years old")
print(f"you are {y} ")

''' 
#input


name = input("enter your name : ")
age = input("enter your age:")
print(f"my name is {name} and age is {age}")


# logical operator
'''
x=3
print(x>1 and x<4)

'''
