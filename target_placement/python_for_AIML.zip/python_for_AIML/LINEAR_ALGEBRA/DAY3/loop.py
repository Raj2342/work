lists = [1,2,3,4,5]
'''
for temp in lists:
            print(temp)

'''
#2
'''
for x in "banan":
            print(x)

'''
# range() function:range(2, 6), which means values from 2 to 6 (but not including 6):
'''

for x in range(3,6):
        print(x)
'''

#range(2, 30, 3):(starting , max num ,how much add) )
'''
for x in range(2,30,10):
        print(x)

'''

# if-else
'''
for x in lists:
       if x==4:
            break
       else:
             print("hi")
       
       
       print(x)
'''
#The else block will NOT be executed if the loop is stopped by a break statement.
# Nested loop
'''
adj = ["red","big","tasty"]
fruits = ["apple","banana","cherry"]

for x in adj:
         for y in fruits:
                 print(x,y)


'''
#  while loop
'''

i=1
while i<6:
      print(i)
      if(i==3):
            continue
      i+=1

'''

# continue statment 
i=0
while i<6:
     i+=1
     if i==3:
           continue
     print(i)
              
