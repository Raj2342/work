a=32
b=34
'''

if a>b:
    print(a)
elif b>a:
      print(b)
else:
    print("i am not sure")

'''
# short hand if fj
if a>b: print
else: print("i donot know")