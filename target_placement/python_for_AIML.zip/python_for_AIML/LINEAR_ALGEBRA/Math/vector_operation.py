import numpy as np
vec1 = np.array([2,4,6,8])
vec2 = np.array([3,6,9,7])

#addation
print("addition of vector " , vec1+vec2)
#substraction
print("substraction of vector " , vec1-vec2)

# scaler multiplication
print("scaler multilication" , 2*vec1)

#dot product
dotProduct = np.dot(vec1,vec2)
print("dot product: 2x3+4x6+6x9+8x7 =" , dotProduct)

#magnitude/ length of vector 
mag = np.linalg.norm(vec1)
print(mag)