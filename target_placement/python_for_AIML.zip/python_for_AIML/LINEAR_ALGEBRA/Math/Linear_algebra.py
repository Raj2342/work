import numpy as np

v= np.array([[1,2,3] , [4,5,6],
             [7,8,9] ,
             [2,3,4]])
print(v.shape) # ans- (4,3)
print(v)
'''
ans: 
[[1 2 3]
 [4 5 6]
 [7 8 9]
 [2 3 4]]
'''
######  practice 
## vector
vector = np.array([9,8,7,6,5])

#matrix
matrix = np.array([[1,2,3,4] , [6,7,8,9]])

print("vector:" ,vector)
print("matrix",matrix)
print("matrix shape",matrix.shape)
print("matrix number of dimensions using .ndim",matrix.ndim)

