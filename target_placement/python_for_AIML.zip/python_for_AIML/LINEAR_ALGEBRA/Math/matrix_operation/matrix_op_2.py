import numpy as np
A = np.array([
            [1,2,3],
            [0,1,4],
            [5,6,0]
])

B = np.array([
            [7,8,9],
            [3,6,1]
])

# INVERSE
Inv_A = np.linalg.inv(A)
print(Inv_A)

#determinant of matrix
det = np.linalg.det(A)
print("determinant\n",int(det))

# eigen value  and eigen vector
value , vector = np.linalg.eig(A)
print("eigne value:\n",value)
print("eigner vector:\n", vector)
#print(vector)     