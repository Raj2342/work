import numpy as np
matrixA = np.array([
            [1,2],
            [3,4]
])
print("this is matrix A:\n",matrixA)
matrixB = np.array([
            [5,6],
            [7,8]
])
print("this is matrix B:\n",matrixB)

# Matrix addition 
print("matrix addition:\n",matrixA+matrixB)
# Matrix substraction 
print("matrix substraction:\n",matrixA-matrixB)

#matrix multiplication
print("matrix multiplication:\n",matrixA @ matrixB)
print("matrix multiplication:\n",np.dot(matrixA , matrixB) )
# matrix dot product 
print("dot product\n " ,matrixA* matrixB)

# transpose of matrix 
print("transpose of matrixA\n",matrixA.T)

#Indentity matrix 
I = np.eye(3)
print("diagonal matrix:\n",I)




