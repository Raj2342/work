import math

print(math.sqrt(16))
print(math.pow(2,3))

# Make a Calculator using Functions
print("function are started")
def sum(a,b):
     print(a+b) 

def sub(a,b):
     print(a-b)

def mul(a,b):
     print(a*b)

def div(a,b):
     print(a//b)

sum(3,4)   
sub(4,5) 
mul(6,7)
div(1,2)

# list Comprehension 
num = [ 1,2,3,4,5,6]
#[expression for item in iterable if condition]
square = [bro*bro for bro in num if bro%2==0]
print(square)

#Nested List Comprehension:
print(" Nested List Comprehension: ")
arr = [1,2,3,4,5,6,7]
matrix=[[j for j in range(3)]for i in range(2)]
print(matrix)