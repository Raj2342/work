#list - question practice 
colors = ["blue", "green","red","white","blue"]
print(colors)
# - Print the 3rd color
print(colors[2])
## - Replace the end color with "black"
colors[len(colors)-1]="black"
print(colors)
# - Add a new color at the end
colors.append("purple")
print(colors)
# USE LOOP
for store in colors:
            print(store)