#index and slice 
li = [1,2,3,4,5]
print(li[2])
#slice
print(li[2:4])
#last 3 element print
print(li[2:])

#dictinory
dic={
       "name":"raj",
       "age":"21"    
}
for key , value in dic.items():
        print(key , " " , value)    