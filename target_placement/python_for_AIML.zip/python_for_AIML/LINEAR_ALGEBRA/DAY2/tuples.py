# tuple -prqactice question
# Create a tuple of 4 numbers.
num = (10,20,30,40)
#Print the first and last elements
print(num[0])
print(num[len(num)-1])
#  Try to change the second element (observe the error)
temp = list(num)
temp[2]=99
num=tuple(temp)
print(num)
# loop 
for woo in num:
            print(woo)