# reate a dictionary for a student with keys: "name", "age", "branch"
student= {
            "name":"raj",
            "age":"23",
            "branch":"ece"
}
#Print the student's name
print(student["name"])
# Print the full dictionary
print(student)
#Change the age to 25
student["age"]=25
print(student)
#Add a new key "grade" with value "A"
student["grade"]="A"
print(student)
# loop print only key
for key in student:
            print(key)
# loop print only values
for Value in student.values():
        print(Value)
#Loop Through Keys and Values:
for key, value in student.items():
        print(key, ":" , value)
