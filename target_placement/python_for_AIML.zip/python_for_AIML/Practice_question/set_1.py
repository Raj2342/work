# for loop and while loop+ if/else question
# wap for even /odd number
'''

n =int(input("enter the number:"))
if n%2==0:
     print("it is even number ")
else:
     print("it is odd number")

'''

#Multiplication Table
#Use a for loop to print the multiplication table of a given number.
'''

num = int(input("enter the number:"))
ans=0
for i in range(1,11):
            ans = i*num
            print(f"{num} x {i} = {ans}")

'''
# factorial of number 
'''
n=int(input("enter the number :"))
i=1
ans=1
while i<=n:
      ans=ans*i
      i +=1
         
print(ans)

'''
# Sum of First N Natural Numbers
'''

n=int(input("enter number"))
ans=0
for i in range(1,n+1):
          ans=ans+i
print(ans)          
'''

# reverse number 
'''

n=int(input("enter the number for revrse "))
ans=0
while n!=0:
      lastdigit= n%10
      ans=ans*10+lastdigit
      n=n//10
print(ans)

'''

# intermediate level 
# check prime number 
'''
n=int(input("enter the number "))
count=0
for i in range(1,n+1):
         if n%i==0:
            count +=1
if count==2:
   print("it is prime number")   
else:
   print("it not prime num")   

'''
#print fibonacci series
'''

n=int(input("enter the nth term"))
prv=1
prv2=0
current=0
if n==0:
   print(prv2) 
elif n==1:
   print(prv2)  
else:
     print(prv2, prv, end=" ")

     for i in range(2,n):
         current=prv+prv2
         prv2 , prv = prv , current
         print(current,end=" ")


'''
# SUM OF DIGIT
'''
n=int(input("Enter the digit: "))
ans=0
while n!=0:
      lastdigit = n%10
      ans=ans+lastdigit
      n=n//10
print(ans)

'''

#Count Vowels in a String
#Input: "hello" → Output: 2 vowels
'''
str = input("Enter the string:")
count=0
str.lower
for i in str:
      if i=='a' or i=='e' or i=='o' or i=='u':
           count+=1
print(count)                  

'''

#Number is Palindrome or Not
n=int(input("enter number: "))
ans=0
while n!=0:
      lastdigit = n%10
      ans = ans*10 + lastdigit   
      n=n//10
print(ans)         




                      



