print("\n===== STUDENT MENU =====")
print("1. View All Students")
print("2. Add Student")
print("3. Update Student")
print("4. Delete Student")
print("5. Exit")
students = [
    ("Raj", 21, "B.TECH"),
    ("Ram", 22, "MCA")
]

while True:

    choice = int(input("Enter your choice: "))

    if choice == 1:
        print("view list")
        for i in students:
            name , age , course =i
            print(f"\nStudent Name: {name}")
            print(f"Student Age: {age}")
            print(f"Student Course: {course}")
    elif choice == 2:
          print("add new student detail")
          name = input("Enter name")
          age = int(input("Enter age"))
          course = input("Enter course")
          new_student = (name , age , course)
          students.append(new_student)
          print("Student added successfully!")
    elif choice==3:
         print(" update details")
         print("what you want chaanges name , age , course ")
         update_choice = input(" write here which option changes ")
         if update_choice=='change name':
              new_name = input("enter new name ")
         elif  update_choice=='change age':
              new_age = int(input("enter new age"))     
         elif  update_choice=='change course':
             new_course = input("enter new course ") 
         
         
         for i in students:
              name , age , course =i
              name=new_name
              age=new_age
              course=new_course
              print(f"\nStudent Name: {name}")
              print(f"Student Age: {age}")
              print(f"Student Course: {course}")
           
                   
                   
         
         
               
