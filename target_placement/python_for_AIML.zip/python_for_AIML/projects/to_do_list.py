print("===== TO-DO LIST MENU  list =====")
print("1.Add Task")
print("2.View Tasks")
print("3.Remove Task")
print("4.Exit")

task=[]  # new information
while(True):
         choice = int(input("Enter your choice (1-4):"))
         if choice==1:
                    new_task = input("Enter the task: \n") 
                    task.append(new_task) 
         elif choice==2:
                   print("Your tasks:")
                   for i,t in enumerate(task , 1):
                           print(f"{i}.{t}")
         elif choice==3:
                 print("Remove Task:")
                  #["buy" , "car" , "bro"]
                 for i , t in enumerate(task , 1):  # new information
                         print(f"{i},{t}")
                 remove = int(input("enetr which task delete"))
                 if 1<=remove<=len(task):  # new information
                         remove_index = task.pop(remove-1)  # new information
                         print("successfully remove" ,remove_index)
                                    
                         
         elif choice==4:
                 print("exit")
                 break
                 
               
                         
                           



