print("===== PHONEBOOK MENU dictinoary =====")
print("1. Add Contact")
print("2. View Contacts")
print("3. Update Contact")
print("4. Delete Contact")
print("5. Exit")

my_dic = {}
while(True):
      chioce = int(input("Enter your choice (1-5):"))
      if chioce==1:
            print("add  user phone number ")
            name = input('enter name')
            phone_no= input("enter phone number")
            my_dic[name]=phone_no
      elif chioce==2:
               print("View Contacts")   
               for i , t in my_dic.items():
                      print(f"{i}.{t}")
      elif chioce==3:
            print("Update Contact")   
            update_name= input("eneter the name")
            update_number= input("eneter the number")
            my_dic[update_name]=update_number
      elif chioce==4:
             print(" Delete Contact")
             for i , t in my_dic.items():
                    print(f"{i}.{t}")

               # my_dic ={ "raj" : "635245865" , "mohan":"524746234"}
             delete = input("eneter person name you want delete")
             del my_dic[delete]
             print("sucessfully deleted"+delete)
      elif chioce==5:
             print('exit')
             break            

                      
            
     

