while True:
         firstNum = int(input("Enter first number:"))
         secondNum = int(input("Enter second number: "))
         print("select operator +,-,*,/")
         operator=input("enter opertaor:")
         if operator=='+' :
             print("addition:",firstNum+secondNum)
         elif operator=='-':
              print("substraction:",firstNum+secondNum)
         elif operator=='*':
               print("multiplication:",firstNum+secondNum)
         elif operator=='//':
               print("division:",firstNum+secondNum) 

         permission = input("do you want calculation again ? (yes/no):") 
         if permission.lower() !='yes':
                        break
      


           
