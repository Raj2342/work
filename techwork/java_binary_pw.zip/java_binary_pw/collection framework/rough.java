import java.util.*;
public class rough {
    public static void main(String[] args) {
         
        ArrayList al1 = new ArrayList();
        al1.add(100);
        al1.add(200);

    }
}