package linkedList;
// this code for only one one box 
class Node {
       int data; 
       Node next;

       Node(int data){
            this.data = data;
            this.next=null;
       }
}

// this code for whole linkedlist
class List{
            Node head;
            Node tail;

            // constructor nonj parametriozed
             List(){
                 head  = null;
                 tail=null;
            }
}

public class singliyLinkedList {
             public static void main(String[] args) {
                        
             }   
}
