package comparable;
import java.util.*;

import ArrayList;

public class comprator_program {
    public static void main(String[] args) {
        Comparator<Integer> com = new Comparator<Integer>(){
              public int compare(Integer i , Integer j)
              {
                   if(i%10 >j%10){
                       return 1;
                   }
                   else{
                       return -1;
                   }
                   
              }
        };
        List<Integer> nums = new ArrayList<>();
        nums.add(12);
        nums.add(34);
        nums.add(55);
        nums.add(54);

        Collections.sort(nums , com);
        System.out.println(nums);  // [12, 34, 54, 55]
    }
}
