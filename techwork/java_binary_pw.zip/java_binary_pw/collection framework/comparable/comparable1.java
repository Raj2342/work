import java.util.*;
class student {
    int age;
    String name;
    
    public student(int age , String name  ){
        this.age = age ;
        this.name = name;
    }
    @Override
    public String toString(){
        return "Student [ age="+age+",name="+name+"]";
    }
}
public class comparable1 {
    public static void main(String[] args) {
        Comparator<Integer> com = new Comparator<Integer>(){
              public int compare(Integer i , Integer j)
              {
                   if(i%10 >j%10){
                       return 1;
                   }
                   else{
                       return -1;
                   }
                   
              }
        };
        
        List<student> nums = new ArrayList<>();
        nums.add(new student(28 , "raju"));
        nums.add(new student(22 , "rohan"));
        nums.add(new student(23 , "sohan"));
        nums.add(new student(24 , "mohan"));
        
        for(student s: nums){
             System.out.println(s);  
        }

      
    }
}
