import java.util.*;
class student  implements  Comparable<student>{
    int age;
    String name;
    
    public student(int age , String name  ){
        this.age = age ;
        this.name = name;
        
    }
    @Override
    public String toString(){
        return "Student [ age="+age+",name="+name+"]";
    }
    
    public int compareTo(student that){
                if(this.age >that.age){
                       return 1;
                   }
                   else{
                       return -1;
                   }
    }
    
}
public class comprable2 {
    public static void main(String[] args) {
        // no use this comparator 
        Comparator<student> com = new Comparator<student>(){
              public int compare(student i , student j)
              {
                   if(i.age >j.age){
                       return 1;
                   }
                   else{
                       return -1;
                   }
                   
              }
        };
        
        List<student> nums = new ArrayList<>();
        nums.add(new student(28 , "raju"));
        nums.add(new student(22 , "rohan"));
        nums.add(new student(23 , "sohan"));
        nums.add(new student(24 , "mohan"));
        
        //  Collections.sort(nums  , com);
        Collections.sort(nums );
        
        for(student s: nums){
             System.out.println(s);  
        }

      
    }
}
