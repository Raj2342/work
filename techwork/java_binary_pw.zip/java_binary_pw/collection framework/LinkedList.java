
public class LinkedList {
    public static void main(String[] args) {
          
        // LinkedList  ll1 = new LinkedList();
        // ll1.add(100);
        // ll1.add(200);
        // ll1.add(300);
        // System.out.println(ll1);
        // LinkedList  ll2 = new LinkedList();
        // ll2.add(1);
        // ll2.add('d');
        // ll2.add("bro");
        // ll2.addFirst(17);
        // ll2.addLast(18);
        // System.out.println(ll2.peek());
        // System.out.println(ll2);
        // System.out.println(ll2.poll());
        // System.out.println(ll2);

        

    }
}
