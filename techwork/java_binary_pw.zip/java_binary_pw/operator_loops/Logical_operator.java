package operator_loops;
class Logical_operator{
    public static void main(String[] args) {
        int a = 10 ;
        int b = 20 ;
        int c = 30 ;
        System.out.println(a<c || b>c);
        System.out.println(a>c || b>c);
    }
}