package operator_loops;

public class loop {
    public static void main(String[] args)
     {
        // ****for LOOP
       /*  for(int i=0; i<5 ; i++)
        {
            System.out.println("*");
        } */

        //** WHILE LOOP
       /* int i=0;
        while(i<5)
        {
            System.out.println("i am son");
            i++;
        } */

        // ***do while loop

        int i=0;
        do{
            System.out.println("*");
            i++;
        } 
        while(i<5); 

    
        




    }
}
