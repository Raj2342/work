public class home {
    public static void main(String[] args) {
         String s = "A PP LE ";

         
         System.out.println(s.replaceAll(" ", ""));
    }
}
