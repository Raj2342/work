public class anagram_word {
    public static void main(String[] args) {
        String st1 = S'
    }
}
