// create  node 
class Node{
    int data;   // Data stored in the node
    Node next;  // Pointer to the next node in the list
    // constructor// for store data directly when obj  creation 
    Node(int new_data){
        data =new_data;
         next = null;
    }
}

public class insert_at_start{

               
    public static void main(String[] args) {
        // 
        // Node Head = new  Node(20);
        // System.out.println(Head.data);
        // System.out.println(Head.next);

        // insert the node at beginning
        Node Head = null;
        int arr[] = {2,4,6,3};

        for(int i=0;i<4;i++){
            // linked list  doesnot exit 
        if(Head== null){
            Head = new Node(arr[i]);
        }
        // linkedlist exit 
        else{
            Node temp = new Node(arr[i]);
            temp.next= Head;
            Head = temp;
        }

        }

        // print linkedlist - traverse linkedlist 
        Node temp = Head;
        while (temp != null) {
            System.out.println(temp.data);
            temp= temp.next;
        }
        
        
           
    }
}