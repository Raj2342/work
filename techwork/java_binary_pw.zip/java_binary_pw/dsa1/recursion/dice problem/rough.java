public class rough {
    public static void func(int n)
    {  if (n==10) {
        return;
    }
    else{
        

    }
       
    }
    public static void main(String[] args) {
        int n =5;
        func(n);
    }
}
