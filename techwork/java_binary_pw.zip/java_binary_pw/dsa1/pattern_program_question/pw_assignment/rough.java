
/*
 *                                                                                                                                            ****
*  *
*  *
***
*
*
*
 */

public class rough {
    public static void main(String[] args) {
        // int size = 7; // Size of the letter P pattern
        // // Outer loop for the height of the letter P
        // for (int i = 0; i < size; i++) {
        //     // Inner loop for the width of the letter P
        //     for (int j = 0; j <= size / 2; j++) {
        //         if (j == 0 || (i == 0 || i == size / 2) && j < size / 2) {
        //             System.out.print("*");
        //         } else if (i < size / 2 && j == size / 2) {
        //             System.out.print("*");
        //         } else {
        //             System.out.print(" ");
        //         }
        //     }
        //     System.out.println();
        // }

        // w
       
    }
}

