public class sum {
    
      public static void main(String[] args) {
            int a[] = { 2,3,4,5,6};
            int sum = a[0];
            for(int i=1; i<a.length;i++){
               sum = sum+a[i] ;
            }
            System.out.println(sum);
      }
} 
