import java.util.Arrays;

public class unsorted_array {
         
       public  static void sort(int arr[]){
             Arrays.sort(arr);
             int[] temp = new int[arr.length];
             
             
       }  
    
    
    public static void main(String[] args) {
          int arr[] = { 5,5,4,3,3,9,9};
          sort(arr);
          System.out.println(Arrays.toString(arr));
          
       }
}
