import java.util.ArrayList;
import java.util.Arrays;

public class rough {
      
    public static void main(String[] args) {
         int a[] = {15,3,7,9,2,10};
         int b[] = {5,1,15,8,3,10};
         int c[] = { 2,4,5,15,4,10};
          
         for(int a1 : c)
         {
          System.out.println(a1);
         }

         
      
        
        
           

    }
}