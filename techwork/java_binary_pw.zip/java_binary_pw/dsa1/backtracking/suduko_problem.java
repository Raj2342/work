import java.util.Scanner;
public class suduko_problem {
    // *********************************display method************** 
    public static void  display(int[][] board)
    {
        for(int i=0;i<board.length-1;i++)
        {
            for(int j=0;j<board[0].length;j++){
                System.out.println(board[i][j]+ " ");
            }
            System.out.println();
        }
    }

// *****************sudko solve logic************** 

    public static void  solveSudko(int[][] board , int i , int j){
        // next row and col
        int ni=0;
        int nj =0;
        int row = board.length-1;
        int col = board[0].length;
           // yadi aaap last column me hai 
        if(j == col){
            // next row
            ni = i+1;
            // column 0
            nj = 0;
        }
        // yadi aap last column me nahi hai 
        else{
        //    same row 
             ni = i;
            //  next column 
             nj = j+1;

        }
    }


    //  *********************main method ***************
    public static void main(String[] args) {
           Scanner sc = new Scanner(System.in);
           int[][] arr = new int[9][9];
           for(int i=0;i<9;i++){
            for(int j=0;j<9;j++){
                arr[i][j]= sc.nextInt();
            }
           }

           solveSudko(arr,0,0);

    }
}
