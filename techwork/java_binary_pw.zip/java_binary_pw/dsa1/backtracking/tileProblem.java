
public class tileProblem {

     public static int  tile(int n){
      if (n==3 || n==2 || n==1|| n==0) {
        return n;
      }

      else{
        return tile(n-1)+tile(n-2);
      }
     }
public static void main(String[] args) {
        
    
      System.out.println("for n=6 , total no. of ways "+tile(6));
      
}
    
}