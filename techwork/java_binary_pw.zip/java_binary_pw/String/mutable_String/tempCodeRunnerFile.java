 StringBuffer sb = new StringBuffer(150);
      //   System.out.println("self made capacity :"+sb.capacity());
      //   sb.append("java");
      //   sb.trimToSize();
      //   System.out.println("it decrease  capacity using property "+sb.capacity());
