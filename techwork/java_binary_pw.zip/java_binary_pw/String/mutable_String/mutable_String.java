package String.mutable_String;


public class mutable_String {
              
     public static void main(String[] args) {
          /*  StringBuffer  s = new StringBuffer(" viral ") ;
            s.append("kohali");
            System.out.println(s);
            // stringbuilder 
      StringBuilder s1 = new StringBuilder(" harry");
      s1.append("kumar");
      System.out.println(s1);
      */

    //    final keyword
     final StringBuffer s1 = new StringBuffer(" hello ");
                s1.append(" world");
          System.out.println(s1);   
          // *** create a new obj
        //   s1 = new StringBuffer(" sachine");
        //   System.out.println(s1);   

     }
}
