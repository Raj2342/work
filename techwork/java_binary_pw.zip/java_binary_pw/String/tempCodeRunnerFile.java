 String  refValriable =  " pw"; 
      //  String  refValriable1 =  " pw"; 
      // System.out.println(refValriable == refValriable1);