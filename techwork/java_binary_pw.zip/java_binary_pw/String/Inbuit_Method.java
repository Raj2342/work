package String;

public class Inbuit_Method {
    
    public static void main(String[] args) {
        
        String str = " pw skills java";
        // System.out.println(str);
         System.out.println(str.length());
        //  System.out.println(str.toLowerCase());
        //  System.out.println(str.toUpperCase());
        // work as a array 
        // System.out.println(str.charAt(1));
        // substring --  (start , end )
        // System.out.println(str.substring(2,9));
        // find string index 
        // System.out.println(str.indexOf( "s"));
        // System.out.println(str.lastIndexOf( "s"));
        
    }    

    
             
}
