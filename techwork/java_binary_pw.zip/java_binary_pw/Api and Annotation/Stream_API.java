import java.util.*;
public class Stream_API {
     public static void main(String[] args) {
          List<Integer> al =  Arrays.asList(2,4,5,6,7,8);
        //  // System.out.println(al);
        
          
     }
}
