import java.time.LocalDate;

public class rough {
    public static void main(String[] args) {
          LocalDate.now();
    }
}
