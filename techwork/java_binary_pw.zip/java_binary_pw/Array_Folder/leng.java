package Array_Folder;

public class leng {
     public static void main(String[] args) {
     //    concept-1 : array has lenght properpety
     /*  int a[] = { 1,2,3,4,5};
        System.out.println(a.length);
      */

     //  2D Array- concept-2

   /*   int nums[][] = {
           { 2,3,4,5}, // it has 3 element {}, {} , {}
           {7,6,5,4},
           {1,3,4,5}

     };
     System.out.println(nums.length);
     // if inside element of element
     System.out.println(nums[0].length);
   */

//    concept-3: string has lenght() method

String name = "mohan";
System.out.println(name.length());

     }
}
