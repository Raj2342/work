package Assignment;
import java.util.Arrays;
import java.util.Scanner;

public  class feb_6{
      public static void main(String[] args) {
         
                Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string value: ");
        String str = sc.nextLine();
        char charArray[] = str.toCharArray();
        Arrays.sort(charArray);
        String so = new String(charArray);
        System.out.println(so);

     
    
    }
 }