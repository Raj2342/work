package Assignment;

  // pass  array in method as argument  you  
public class feb_1 {
      
    public static void main(String[] args) {
      
     /*  // exaple-3 
      int a = 3;
      int b=4;
     int addition =  add(a,b);
      System.out.println(a+"+"+ b+"="+addition);

       a = 4;
       b=5;
      addition =  add(a,b);
      System.out.println(a+"+"+ b+"="+addition);

       a = 14;
       b=15;
      addition =  add(a,b);
      System.out.println(a+"+"+ b+"="+addition);

      */



   
   
   
   
   
   
      /*    // example-2
      String  name1 = " sohan";
        name(name1);
      String  name2 = " mohan";
      name(name2);
      String  name3 = " vivek";
      name(name3);
      String  name4 = " rohit";
      name(name4);
       */
      
      /*   //example-1
        int marks[] = { 1,2,3,4,5,6};
        display(marks); */ //  benefit in java there is no need to  write [] when you call or assign 
        
    }
/*  // example-1
    public  static void display(int input[]){
         for( int counter=0;  counter<input.length; counter++){
            System.out.println(input[counter]);
         }
    }
    */

   /*  // example-2
    public static void name(String  name){
        System.out.println(" hi  i am a " + name);

    }
*/

  /*//  exaplme-3
public static int  add(int x,  int y){
       int sum = x+y;
       return sum;
}
*/

  }
