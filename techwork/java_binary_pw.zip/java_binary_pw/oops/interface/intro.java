 interface animal {
      int a =7;
    void eat();
    // we canot give body becoz invisible  abstract method  are marked 
 }


class intro{
     public static void main(String[] args) {
         System.out.println(animal.a);
        //  animal.a=4; we canot  edit "a" beocz it is final  interface give automatically 

     }
}