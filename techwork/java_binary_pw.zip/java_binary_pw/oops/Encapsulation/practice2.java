



public class practice2 {
    
    public static void main(String[] args) {
            
       

           
    }
    
}
