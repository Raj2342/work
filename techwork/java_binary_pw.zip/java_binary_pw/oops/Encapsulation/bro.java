
public class bro{

            bro(String name){
                        System.out.println(name);
            }
            public static void main(String[] args) {
                     bro an = new bro("raj");
                     
            }
}