public class REMO {
    public  void main(String[] args) {
        System.out.println("hell");
    }
}
