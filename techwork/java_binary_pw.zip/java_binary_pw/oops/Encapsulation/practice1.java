/////////////////  PROGRAM-1 ///////////////////////////////////////////////

// // prit geek for geeks 

// class Getset{
      
//      private String  name ;

//      public void setName(String  name){
//             this.name = name;
//      }

//      public String getName(){
//           return name;
//    }
// }





// public class practice1 {
          
//        public static void main(String[] args) {
//            Getset obj = new Getset();
//            obj.setName(" geek for geeks ");
//           String stroge = obj.getName() ;
//           System.out.println(stroge);
           
           
//        }
// }


/////////////////  PROGRAM-2 ///////////////////////////////////////////////
// practice problem 
 







