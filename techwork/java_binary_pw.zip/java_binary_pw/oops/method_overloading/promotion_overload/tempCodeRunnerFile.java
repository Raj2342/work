
       public static  void calc(int a){
         System.out.println("int "+a);
       }