package java_basic;
      // implicit type casting 
public class type_casting {
     public static void main(String[] args) {
           byte p = 12;
           System.out.println("byte no." +p);
          short q = p ;
            System.out.println("short no."+q);
           int r=q;
           System.out.println("int no."+r); 
           long s=r;
           System.out.println("long no."+s);
           float m =s;
           System.out.println("float no."+m);
           double k = m;
           System.out.println("double no."+k);

     }
}
