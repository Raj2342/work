package java_basic;
public class increment_decre{
       public static void main(String[] args) {
        //  pre-increment
        int a = 45;
        int   b= ++a;
        System.out.println(a);
        System.out.println(b);
        // post increment 
         int c = 45;
        int   d= a++;
        System.out.println(c);
        System.out.println(d);
       }
}