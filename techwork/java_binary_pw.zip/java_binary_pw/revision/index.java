public class index {

         index(){
            System.out.println("hello world");
         }
    public static void main(String[] args) {
           // default constructor
           index in = new index();
    }
}