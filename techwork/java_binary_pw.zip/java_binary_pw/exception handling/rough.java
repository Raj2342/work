 class animal{
            int a =5;
 }


public class rough {
            public static void main(String[] args) {
                        animal an = new animal();
                        an.a=10;
                        System.out.println(an.a);
            }
}