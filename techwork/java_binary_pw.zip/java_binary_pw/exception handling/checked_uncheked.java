import java.io.FileInputStream;
public class checked_uncheked {
    public static void main(String[] args) {
        FileInputStream fs = new FileInputStream("jf");

    }
}
