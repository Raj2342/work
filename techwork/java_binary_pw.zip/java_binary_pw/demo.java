

class demo 
{
        public static void main(String[] args) {
             String  st = "PESKILLS";
             char    st1 = st.
            System.out.println(st1);

             
                
               
              


        }
}