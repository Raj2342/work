// ARMSTRONG NUMBER -  COUNT DIGIT + REVERSE NUMBER + 

public class armstrong {
   
    public static void main(String[] args) {
        int original = 153;
        int t1 = original;
        int count =0;
        int lastDigit =0;
        while(t1 != 0){
      
          t1 = t1/10;
          count++;  
        }
        System.out.println(count);
 
         //  reverse number
        
        int t2 = original;
        int arm =0;
        int rem =0;
        while (t2 !=0) {
            int mul =1;
          rem = t2%10;
         for(int i=0;i<=count;i++){
             mul = mul*rem;
          }
          // arm use for add 3 digit 1^3+5^3+3^3
        arm = arm+mul;
        t2 = t2/10;
        }
 
        if(arm == original){
          System.out.println("armstrong number");
        }
        else{
         System.out.println("not armstrong ");
        }
       

        
        

    }
}
