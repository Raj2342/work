import java.util.Arrays;

public class palindrome {
    public static void main(String[] args) {
         int arr[] = { 1,2,3,2,1};
         int newarr[] = new int[arr.length];
         for(int i=arr.length-1;i>=1;i--){
             newarr[i] = arr[i];
         }
         System.out.println(Arrays.toString(newarr));
    }
}
