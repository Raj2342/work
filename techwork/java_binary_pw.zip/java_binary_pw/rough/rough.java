public class rough {
    public static void main(String[] args) {
        int n = 153;
        int original=n;
        // count number of digit  in n
          int count =0;
          while (n != 0) {
             n= n/10;
             
            count++;
          }

          // reverse numnber 

          while (n != 0) {
            n=n%10;
            for(int i=0;i<count;i++){
                n
            }
          }
    }
}
