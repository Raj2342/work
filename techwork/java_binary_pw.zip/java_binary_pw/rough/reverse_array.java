import java.util.ArrayList;

public class reverse_array {

    public  static void reverse(int arr[], int n){
        ArrayList ai = new ArrayList<>();
         for(int i=arr.length-1; i>=0;i--){
              ai.add(arr[i]);
         }
         System.out.println(ai);
    }
    public static void main(String[] args) {
        int arr[] = {1,2,3,4,5};
        int n =5;
        reverse(arr,n);
    }
}
