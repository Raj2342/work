import java.util.Scanner;

class Animal extends Thread {
    
    @Override
    public void run() {
        String threadName = Thread.currentThread().getName();

        if (threadName.equals("meme")) {
            calculation();
        } else {
            message();
        }
    }

    public void message() {
        System.out.println("Displaying important message task");
        try {
            for (int i = 0; i < 3; i++) {
                System.out.println("Focus is important to master skills");
                Thread.sleep(2000); // Pause for 2 seconds
            }
        } catch (Exception e) {
            System.out.println("Some problem occurred in message task");
        }
        System.out.println("Displaying important message task ended");
    }

    public void calculation() {
        System.out.println("Calculation Task Started");

        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter first number:");
        int num1 = sc.nextInt();

        System.out.println("Please enter second number:");
        int num2 = sc.nextInt();

        int result = num1 + num2;

        System.out.println("Result: " + result);
        System.out.println("Calculation Task Ended");
        System.out.println("****************************************************");
 
        sc.close();
    }
}

public class SingleRunMultiTask {
    public static void main(String[] args) {

        // Create two thread objects
        Animal thread1 = new Animal();
        Animal thread2 = new Animal();

        // Assign names to differentiate their tasks
        thread1.setName("meme");  // Will perform calculation
        thread2.setName("calu");  // Will show messages

        // Start both threads
        thread1.start();
        thread2.start();
    }
}
