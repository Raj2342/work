import java.util.Arrays;
import java.util.Collections;

public class second_large_ele {

    public static void largeEle(Integer[] arr, int n) {
        // sort in decreasing order 
        Arrays.sort(arr, Collections.reverseOrder());
        for(int i=0;i<n;i++)
        {
             // arr[0]-- biggest element 
            if (arr[i] !=arr[0]) {
                System.out.println(arr[i]);
                return;
            }
        }
         
    }

    public static void main(String[] args) {
        Integer[] arr = {2, 4, 6, 8, 9};  // Note the use of Integer[]
        int n = arr.length;
        largeEle(arr, n);
        // System.out.println(Arrays.toString(arr));
     
    }
}
