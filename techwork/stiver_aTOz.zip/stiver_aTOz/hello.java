import java.util.*;
public class hello {

    public static int  second(int arr[],int n)
    {
          int largest = -1;
          int secondlargest =-1;

         for(int i=0;i<arr.length;i++){
           
              largest = Math.max(largest,arr[i]);
         }

         for(int i=0;i<arr.length;i++)
         {
            if (arr[i] != largest) {
                secondlargest = Math.max(secondlargest, arr[i]);
            }
         }

         return secondlargest;
    }
    public static void main(String[] args) {
        int arr[]={ 2,4,6,8,10,12};
        int n = arr.length;
      int result=  second(arr,n);
      System.out.println(result);
    }
}
