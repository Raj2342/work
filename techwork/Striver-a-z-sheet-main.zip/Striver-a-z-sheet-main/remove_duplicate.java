public class remove_duplicate {
    public static void main(String[] args) {
         
    }
}
