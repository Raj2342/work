import java.util.*;

class without_sort_second_ele {
   public static int print2largest(int arr[], int n)
    {

       int  largest =-1 , secondLargest =-1;
       //largest element
        for(int i=0;i<arr.length;i++)
        {
            largest= Math.max(largest, arr[i]);
        }
         
for(int i=0;i<arr.length;i++){
     if (arr[i] != largest) {
        secondLargest = Math.max(secondLargest, arr[i]);
     }
}

return secondLargest;
       
    }

    public static void main(String[] args) {
          int arr[] = { 2,3,4,5,6,7};
          int n=arr.length;
       int b=   print2largest(arr,n);
       System.out.println(Arrays.toString(arr));
       System.out.println(b);
    }
}