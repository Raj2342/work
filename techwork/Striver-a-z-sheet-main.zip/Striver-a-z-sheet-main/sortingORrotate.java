public class sortingORrotate {

    public static boolean check(int arr[])
    {
        if (arr[]) {
            
        }
    }
    public static void main(String[] args) {
          int arr[] = {3,4,5,1,2};
          check(arr);
    }
}
