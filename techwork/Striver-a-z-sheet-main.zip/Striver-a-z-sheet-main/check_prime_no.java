public class check_prime_no {

    public static void primeno(int n){
            
        if(n%1==0 && n%n == 0 && n%2 !=0 && n%3 !=0){
         System.out.println("prime no.");
        }
        else{
            System.out.println("NOT PRIME NO.");
        }
    }
    public static void main(String[] args) {
         int n =54;
         primeno(n);
    }
}
