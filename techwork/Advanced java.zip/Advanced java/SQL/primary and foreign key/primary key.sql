SELECT * FROM wscube.cities;
alter table cities
add primary key(id)