use wscube;
create table player(
 id int(20) not null unique,
 name varchar(20)  not null,
 email varchar(40) not null unique,
 age tinyint check(age>=18),
 status  boolean default 1
  
);