use wscube;
insert into  player( id,name ,email,age, status) 
values
       (3,"sohan","sohan554@gmail.com",30,0);