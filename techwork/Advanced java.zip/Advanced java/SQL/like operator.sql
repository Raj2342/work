use wscube;
-- Select*from student where name like "p%" and gender="M"; 
-- Select*from student where name like "%a" ; 
-- Select*from student where name like "%i%"; 
-- Select name,city,gender from student where  city like "_a%"
 -- Select*from student where name like "p____"; -- parul , ____ = 4 dash 
-- Select*from student where name like "p____%";  -- piyush , prince , parul , ____ = 4 dash+ multiple character
 Select*from student where name like "r%a"; 
