 use wscube;
 -- delete from player where id =4;
 delete from player where id in(3,4);