use wscube;
UPDATE student set city ='shrilanka' , name ='Ravan', gender='t' where id=4 
                   