use wscube;
insert into student( id , name , email,city,gender) 
				  values( 2,"Riya" , "riyakumari@gmail.com", "kanpur","F"),
                  ( 3,"john" , "john@gmail.com", "America","M"),
                     ( 4,"Ankur" , "Ankur@gmail.com", "mamupur","M"),
                        ( 5,"dimple" , "dimple@gmail.com", "mohali","F"),
                           ( 6,"smita" , "smita@gmail.com", "morinda","F"),
                              ( 7,"piyush" , "piyush@gmail.com", "rampur","M"),
                                 ( 8,"prince" , "prince@gmail.com", "sitapur","M"),
                                    ( 9,"parul" , "parul@gmail.com", "palampur","F");