-- SELECT * from wscube.user;
-- SELECT id ,name ,email from wscube.user;
-- SELECT id as "roll no.",name as "student name ",email from wscube.user;
--  select * from wscube.user where id<4;
 select * from wscube.user where gender="m";