-- select *from student order by name asc;
-- select *from student order by id desc;
select distinct gender from student  order by gender desc;