  -- string function
 /*SELECT concat( best_student.name,best_student.city) as mix  FROM wscube.best_student 
where id =5
*/

-- date and time function 
SELECT CURTIME();