use  wscube;
-- count 
select  count(id) dui from best_student where  age>21;

-- sum 
select sum(age) from best_student;

-- average
select avg(age) from best_student;

-- min
select min(age) from best_student;

-- max 
select max(age) from best_student;