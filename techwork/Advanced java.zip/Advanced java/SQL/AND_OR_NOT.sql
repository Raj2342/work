use wscube;
-- select*from user where id>2  and gender="m" and id<5;
-- select*from user where gender="h"  or gender="m";
select*from user where  not address="delhi";