-- SELECT*FROM player where age=19 or age =30;
SELECT*FROM player where age IN(19,121 );