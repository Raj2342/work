TRUNCATE TABLE player ;  -- it delete all data from table but not delete table 
