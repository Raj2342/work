use wscube;
insert into user( id,name,email, passwaord , contact , address,dob,gender,status) values(4,"bhagat","bhagat@gmail.com","bangbang","839563122", "agra" , "2000-09-8" , "M" , 1),
                                                                                        (5,"vishal","vishal@gmail.com","visbang","9687287539", "mumbai" , "2001-08-06" , "M" , 0),
                                                                                        (6,"ranjan","ranjan@gmail.com","sas@1234","9242648759", "karnatka" , "1998-08-02" , "M" , 0);